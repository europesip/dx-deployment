# hcl-dx-search Helm Charts

This Helm Chart contains the deployment of HCL Digital Experience.

Please visit [HCL Digital Experience - Helm based deployments](https://opensource.hcltechsw.com/digital-experience/latest/platform/kubernetes/overview/) for detailed installation instructions.

