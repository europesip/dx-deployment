{{/*
********************************************************************
* Licensed Materials - Property of HCL                             *
*                                                                  *
* Copyright HCL Technologies Ltd. 2023, 2024. All Rights Reserved. *
*                                                                  *
* Note to US Government Users Restricted Rights:                   *
*                                                                  *
* Use, duplication or disclosure restricted by GSA ADP Schedule    *
********************************************************************
*/}}

{{/*
This file compiles the conditional statements that decide, whether
an application will be deployed or not.
*/}}

{{/* OpenSearch condition */}}
{{/* Will be deployed if directly enabled*/}}
{{- define "hcl-dx-search.openSearchEnabled" -}}
  {{- if (.Values.applications.openSearch) -}}
    {{- printf "true" -}}
  {{- else -}}
    {{- printf "false" -}}
  {{- end -}}
{{- end -}}

{{/* Search Middleware condition */}}
{{/* Will be deployed if directly enabled*/}}
{{- define "hcl-dx-search.searchMiddlewareEnabled" -}}
  {{- if (.Values.applications.searchMiddleware) -}}
    {{- printf "true" -}}
  {{- else -}}
    {{- printf "false" -}}
  {{- end -}}
{{- end -}}

{{/* File Processor condition */}}
{{/* Will be deployed if directly enabled*/}}
{{- define "hcl-dx-search.fileProcessorEnabled" -}}
  {{- if (.Values.applications.fileProcessor) -}}
    {{- printf "true" -}}
  {{- else -}}
    {{- printf "false" -}}
  {{- end -}}
{{- end -}}