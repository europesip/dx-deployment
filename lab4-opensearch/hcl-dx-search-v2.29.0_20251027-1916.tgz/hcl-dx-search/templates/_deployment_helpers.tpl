{{/*
********************************************************************
* Licensed Materials - Property of HCL                             *
*                                                                  *
* Copyright HCL Technologies Ltd. 2023. All Rights Reserved.       *
*                                                                  *
* Note to US Government Users Restricted Rights:                   *
*                                                                  *
* Use, duplication or disclosure restricted by GSA ADP Schedule    *
********************************************************************
*/}}

{{/*
This file compiles helpers regarding the overall deployment
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "hcl-dx-search.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "hcl-dx-search.fullname" -}}
{{- if contains .Chart.Name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "hcl-dx-search.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "hcl-dx-search.labels" -}}
release: "{{ .Release.Name }}"
helm.sh/chart: {{ include "hcl-dx-search.chart" . }}
{{ include "hcl-dx-search.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "hcl-dx-search.selectorLabels" -}}
app.kubernetes.io/name: {{ include "hcl-dx-search.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create ambassador id
*/}}
{{- define "hcl-dx-search.ambassadorID" -}}
    {{- if .Values.global.emissaryID }}
      {{- printf .Values.global.emissaryID -}}
    {{- else if .Values.global.ambassadorID -}}
      {{- printf .Values.global.ambassadorID -}}
    {{- end -}}
{{- end -}}

{{/*
Check is SoFy deployment
*/}}
{{- define "hcl-dx-search.isSofyDeployment" -}}
  {{- if .Values.global }}
    {{- if (include "hcl-dx-search.ambassadorID" .) }}
      {{- printf "true" -}}
    {{- else -}}
      {{- printf "false" -}}
    {{- end -}}
  {{- else -}}
    {{- printf "false" -}}
  {{- end -}}
{{- end -}}

{{/*
Create image pull secrets
*/}}
{{- define "hcl-dx-search.imagePullSecret" -}}
imagePullSecrets:
  {{- if (.Values.global) }}
    {{- if (.Values.global.hclImagePullSecret) }}
  - name: {{ .Values.global.hclImagePullSecret }}
    {{- end }}
  {{- end }}
  {{- if (.Values.images) }}
    {{- if (.Values.images.imagePullSecrets) }}
  {{- toYaml (.Values.images.imagePullSecrets) | nindent 2 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Create image repository path
*/}}
{{- define "hcl-dx-search.imageRepository" -}}
  {{- if (include "hcl-dx-search.ambassadorID" .) }}
    {{- if eq .Values.global.hclImageRegistry "hclcr.io/sofy" -}}
      hclcr.io
    {{- else if eq .Values.global.hclImageRegistry "gcr.io/blackjack-209019" -}}
      gcr.io/blackjack-209019/services
    {{- else if eq .Values.global.hclPreviewImageRegistry "hclcr.io/sofy-hcl-users" -}}
      hclcr.io/sofy-hcl-users/services
    {{- else -}}
      {{- printf .Values.global.hclImageRegistry -}}
    {{- end -}}
  {{- else -}}
    {{- printf .Values.images.repository -}}
  {{- end -}}
{{- end -}}

{{/*
Helper function to check if a secret is deployed in the namespace and all data attributes are present.
This function accepts a dictionary as input with the following keys:
  "secretName" is the name of the secret to check
  "requiredDataAttributes" must be a list of data attributes to check
  "globalScope" passes in the global scope to be restored in this context. (will be "." in most cases)
*/}}

{{- define "hcl-dx-search.checkSecretAndDataExists" -}}
  {{- /* Keep the input scope available under $input. This holds all parameters passed to the defined function */ -}}
  {{- $input := . }}
  {{- /* Restore the global scope to access known variables using the dot notation (e.g. .Release.Name) */ -}}
  {{- with $input.globalScope -}}
    {{- /* Try to lookup the provided secret */ -}}
    {{- $currentSecret := (lookup "v1" "Secret" .Release.Namespace $input.secretName ) -}}
    {{- /* Throw an error if the secret is not yet deployed in the namespace */ -}}
    {{- if not $currentSecret -}}
      {{- fail (printf "The secret '%s' was set in the values  but it could not be found in the namespace '%s' in Kubernetes. Please make sure the secrets were added to the cluster before deploying DX." $input.secretName .Release.Namespace ) -}}
    {{- end }}
    
    {{- $errors := list -}}
    {{- /* Make sure all required attributes are set in the secrets "data" field */ -}}
    {{- range $requiredValue := $input.requiredDataAttributes -}}
      {{- if not (get $currentSecret.data $requiredValue) -}}
        {{- $errors = append $errors $requiredValue -}}
      {{- end }}
    {{- end }}
    {{- /* If one or more attributes are missing we throw an error */ -}}
    {{- if not (empty $errors) -}}
      {{- fail (printf "The secret '%s' is missing the required value(s) '%s' in its data." $input.secretName (join ", " $errors)) -}}
    {{- end }}
  {{- end }}
{{- end}}

{{/*
Define reusable secret checksum for search-middleware
*/}}
{{- define "hcl-dx-search.searchCredentialsChecksum" -}}
  {{- /* Setting default search and push username and passwords values */ -}}
  {{- $searchAdminUser := .Values.security.administration.searchAdminUser }}
  {{- $searchAdminPassword := .Values.security.administration.searchAdminPassword }}
  {{- $pushAdminUser := .Values.security.pushAdministration.pushAdminUser }}
  {{- $pushAdminPassword := .Values.security.pushAdministration.pushAdminPassword }}

  {{- /* Checking if validations are passed for searchAdminUser and searchAdminPassword. If passed then credentials are fetched from the custom secret  */ -}}
  {{- if (eq (include "hcl-dx-search.isCustomAdminSecretUsed" .) "true") }}
    {{- $currentCustomSearchAdminSecret := (lookup "v1" "Secret" .Release.Namespace .Values.security.administration.customSearchAdminSecret ) }}
    {{- $searchAdminUser = (b64dec (get $currentCustomSearchAdminSecret.data "username")) }}
    {{- $searchAdminPassword = (b64dec (get $currentCustomSearchAdminSecret.data "password")) }}
  {{- end -}}

  {{- /* Checking if validations are passed for pushAdminUser and pushAdminPassword. If passed then credentials are fetched from the custom secret  */ -}}
  {{- if (eq (include "hcl-dx-search.isCustomPushAdminSecretUsed" .) "true") }}
    {{- $currentCustomPushAdminSecret := (lookup "v1" "Secret" .Release.Namespace .Values.security.pushAdministration.customPushAdminSecret ) }}
    {{- $pushAdminUser = (b64dec (get $currentCustomPushAdminSecret.data "username")) }}
    {{- $pushAdminPassword = (b64dec (get $currentCustomPushAdminSecret.data "password")) }}
  {{- end -}}

  {{- /* Creating the final checksum for core  */ -}}
  {{- printf (printf "%s %s %s %s" ($searchAdminUser | sha256sum) ($searchAdminPassword | sha256sum) ($pushAdminUser | sha256sum) ($pushAdminPassword | sha256sum) ) | sha256sum -}}
{{- end -}}

{{/*
Search-middleware Administration Secret used to get the credentials
*/}}
{{- define "hcl-dx-search.isCustomAdminSecretUsed" -}}
  {{- /* Error: Credentials are set both via values as well as secret */ -}}
  {{- if and (.Values.security.administration.customSearchAdminSecret) (or .Values.security.administration.searchAdminUser .Values.security.administration.searchAdminPassword) }}
    {{- fail "Either security.administration.searchAdminUser or security.administration.searchAdminPassword are set even though a custom secret was provided in security.administration.customSearchAdminSecret. Please explicitly set the unused credentials to be empty/null " }}
  {{- /* Error: Neither of the options to set credentials is used */ -}}
  {{- else if and (not (.Values.security.administration.customSearchAdminSecret)) (not (.Values.security.administration.searchAdminUser)) }}
    {{- fail "Please provide a credential setup for the Search-middleware Administration credentials by either setting security.administration.searchAdminUser and security.administration.searchAdminPassword or by referencing a secret in security.administration.customSearchAdminSecret" }}
  {{- else if (.Values.security.administration.customSearchAdminSecret) }}
    {{- /* Custom secret is used. Check if it is present and correct in the namespace */ -}}
    {{- include "hcl-dx-search.checkSecretAndDataExists" (dict "requiredDataAttributes" (list "username" "password") "secretName" .Values.security.administration.customSearchAdminSecret "globalScope" . ) -}}
    {{- printf "true" -}}
  {{- else }}
    {{- /* Fallback to legacy credential secret */ -}}
    {{- printf "false" -}}
  {{- end }}
{{- end }}

{{/*
Search-middleware Push Administration Secret used to get the credentials
*/}}
{{- define "hcl-dx-search.isCustomPushAdminSecretUsed" -}}
  {{- /* Error: Credentials are set both via values as well as secret */ -}}
  {{- if and (.Values.security.pushAdministration.customPushAdminSecret) (or .Values.security.pushAdministration.pushAdminUser .Values.security.pushAdministration.pushAdminPassword) }}
    {{- fail "Either security.pushAdministration.pushAdminUser or security.pushAdministration.pushAdminPassword are set even though a custom secret was provided in security.pushAdministration.customPushAdminSecret. Please explicitly set the unused credentials to be empty/null " }}
  {{- /* Error: Neither of the options to set credentials is used */ -}}
  {{- else if and (not (.Values.security.pushAdministration.customPushAdminSecret)) (not (.Values.security.pushAdministration.pushAdminUser)) }}
    {{- fail "Please provide a credential setup for the Search-middleware Push Administration credentials by either setting security.pushAdministration.pushAdminUser and security.pushAdministration.pushAdminPassword or by referencing a secret in security.pushAdministration.customPushAdminSecret" }}
  {{- else if (.Values.security.pushAdministration.customPushAdminSecret) }}
    {{- /* Custom secret is used. Check if it is present and correct in the namespace */ -}}
    {{- include "hcl-dx-search.checkSecretAndDataExists" (dict "requiredDataAttributes" (list "username" "password") "secretName" .Values.security.pushAdministration.customPushAdminSecret "globalScope" . ) -}}
    {{- printf "true" -}}
  {{- else }}
    {{- /* Fallback to legacy credential secret */ -}}
    {{- printf "false" -}}
  {{- end }}
{{- end }}