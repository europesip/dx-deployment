{{/*
********************************************************************
* Licensed Materials - Property of HCL                             *
*                                                                  *
* Copyright HCL Technologies Ltd. 2023. All Rights Reserved.       *
*                                                                  *
* Note to US Government Users Restricted Rights:                   *
*                                                                  *
* Use, duplication or disclosure restricted by GSA ADP Schedule    *
********************************************************************
*/}}

{{/*
  This file compiles the conditional statements that decide
  how an application is configured for internal and external communication.
*/}}

{{- define "hcl-dx-search.manager-endpoints" -}}
{{- $replicas := int (toString (.Values.scaling.replicas.openSearchManager)) }}
{{- $nodeName := .Release.Name }}
  {{- range $i, $e := untilStep 0 $replicas 1 -}}
{{ $nodeName }}-open-search-manager-{{ $i }},
  {{- end -}}
{{- end -}}