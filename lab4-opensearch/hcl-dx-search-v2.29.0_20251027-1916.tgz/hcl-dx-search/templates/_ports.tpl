{{/*
********************************************************************
* Licensed Materials - Property of HCL                             *
*                                                                  *
* Copyright HCL Technologies Ltd. 2023, 2024. All Rights Reserved. *
*                                                                  *
* Note to US Government Users Restricted Rights:                   *
*                                                                  *
* Use, duplication or disclosure restricted by GSA ADP Schedule    *
********************************************************************
*/}}

{{/*
This file is a central place to reuse ports in different places
of the applications
*/}}

{{/*
OpenSearch Applications Ports
*/}}

{{- define "hcl-dx-search.ports.openSearch.http" -}}
  {{- printf "9200" -}}
{{- end -}}

{{- define "hcl-dx-search.ports.openSearch.transport" -}}
  {{- printf "9300" -}}
{{- end -}}

{{- define "hcl-dx-search.ports.openSearch.metrics" -}}
  {{- printf "9600" -}}
{{- end -}}

{{- define "hcl-dx-search.openSearchServicePortList" -}}
- name: "http"
  port: {{ include "hcl-dx-search.ports.openSearch.http" . }}
- name: "transport"
  port: {{ include "hcl-dx-search.ports.openSearch.transport" . }}
- name: "metrics"
  port: {{ include "hcl-dx-search.ports.openSearch.metrics" . }}
{{- end -}}

{{- define "hcl-dx-search.openSearchContainerPortList" -}}
- name: "http"
  containerPort: {{ include "hcl-dx-search.ports.openSearch.http" . }}
- name: "transport"
  containerPort: {{ include "hcl-dx-search.ports.openSearch.transport" . }}
- name: "metrics"
  containerPort: {{ include "hcl-dx-search.ports.openSearch.metrics" . }}
{{- end -}}

{{- define "hcl-dx-search.searchMiddlewareServicePortList" -}}
- name: "http"
  port: {{ include "hcl-dx-search.ports.global.nodeApplication" . }}
{{- end -}}

{{- define "hcl-dx-search.searchMiddlewareContainerPortList" -}}
- name: "http"
  containerPort: {{ include "hcl-dx-search.ports.global.nodeApplication" . }}
{{- end -}}

{{/*
Node.js Applications Ports
*/}}

{{- define "hcl-dx-search.ports.global.nodeApplication" -}}
  {{- printf "3000" -}}
{{- end -}}

{{/*
File Processor Ports
*/}}

{{- define "hcl-dx-search.ports.fileProcessor.http" -}}
  {{- printf "9998" -}}
{{- end -}}


{{- define "hcl-dx-search.fileProcessorServicePortList" -}}
- name: "http"
  port: {{ include "hcl-dx-search.ports.fileProcessor.http" . }}
{{- end -}}

{{- define "hcl-dx-search.fileProcessorContainerPortList" -}}
- name: "http"
  containerPort: {{ include "hcl-dx-search.ports.fileProcessor.http" . }}
{{- end -}}
