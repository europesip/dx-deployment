{{/*
********************************************************************
* Licensed Materials - Property of HCL                             *
*                                                                  *
* Copyright HCL Technologies Ltd. 2023, 2025. All Rights Reserved. *
*                                                                  *
* Note to US Government Users Restricted Rights:                   *
*                                                                  *
* Use, duplication or disclosure restricted by GSA ADP Schedule    *
********************************************************************
*/}}

{{/*
  CONFIG MAP KEYS AND VALUES MUST BE ENCLOSED IN DOUBLE QUOTES
  CONFIG MAP KEYS MUST BE SORTED ALPHABETICALLY
  ENTRIES MUST BE TRIMMED MANUALLY + 1 WHITESPACE AFTER COLON
*/}}

{{- define "hcl-dx-search.searchMiddlewareConfig" -}}
"autosetup_dam_aclLookupHost": "{{ .Values.configuration.automatedSetup.digitalAssetManagement.aclLookupHost }}"
"autosetup_dam_enabled": "{{ .Values.configuration.automatedSetup.digitalAssetManagement.enabled }}"
"autosetup_dam_uuid": "{{ .Values.configuration.automatedSetup.digitalAssetManagement.uuid }}"
"autosetup_dx_deployment_name": "{{ .Values.configuration.automatedSetup.dxDeploymentName }}"
"autosetup_jcr_aclLookupHost":  "{{ .Values.configuration.automatedSetup.jcr.aclLookupHost }}"
"autosetup_jcr_crawler_uuid":  "{{ .Values.configuration.automatedSetup.jcr.crawlerUuid }}"
"autosetup_jcr_enabled": "{{ .Values.configuration.automatedSetup.jcr.enabled }}"
"autosetup_jcr_schedule": "{{ .Values.configuration.automatedSetup.jcr.crawlerSchedule }}"
"autosetup_jcr_uuid": "{{ .Values.configuration.automatedSetup.jcr.uuid }}"
"autosetup_people_aclLookupHost": "{{ .Values.configuration.automatedSetup.people.aclLookupHost }}"
"autosetup_people_aclLookupPath": "{{ .Values.configuration.automatedSetup.people.aclLookupPath }}"
"autosetup_people_enabled": "{{ .Values.configuration.automatedSetup.people.enabled }}"
"autosetup_people_uuid": "{{ .Values.configuration.automatedSetup.people.uuid }}"
"autosetup_portal_aclLookupHost":  "{{ .Values.configuration.automatedSetup.portal.aclLookupHost }}"
"autosetup_portal_crawler_uuid":  "{{ .Values.configuration.automatedSetup.portal.crawlerUuid }}"
"autosetup_portal_enabled": "{{ .Values.configuration.automatedSetup.portal.enabled }}"
"autosetup_portal_schedule": "{{ .Values.configuration.automatedSetup.portal.crawlerSchedule }}"
"autosetup_portal_uuid": "{{ .Values.configuration.automatedSetup.portal.uuid }}"
"autosetup_wcm_aclLookupHost":  "{{ .Values.configuration.automatedSetup.wcm.aclLookupHost }}"
"autosetup_wcm_crawler_uuid":  "{{ .Values.configuration.automatedSetup.wcm.crawlerUuid }}"
"autosetup_wcm_enabled": "{{ .Values.configuration.automatedSetup.wcm.enabled }}"
"autosetup_wcm_schedule": "{{ .Values.configuration.automatedSetup.wcm.crawlerSchedule }}"
"autosetup_wcm_uuid": "{{ .Values.configuration.automatedSetup.wcm.uuid }}"
"common_fields_mapping.json": | {{ toPrettyJson .Values.commonFieldMappings | nindent 2 }}
"cors_origin": "{{ .Values.configuration.searchMiddleware.corsOrigin }}"
"fileprocessor_host": "{{ .Release.Name }}-file-processor"
"fileprocessor_mime_type_whitelist": "{{- join "," .Values.configuration.textExtraction.allowedMimeTypes }}"
"opensearch_host": "{{ .Release.Name }}-open-search-data"
"picker_ui_context_root": "{{ .Values.configuration.picker.contextRoot.ui }}"
"search_middleware_context_root": "{{ .Values.configuration.picker.contextRoot.api }}"
"search_middleware_host": "{{ .Values.configuration.searchMiddleware.host }}"
"search_middleware_port": "{{ .Values.configuration.searchMiddleware.port }}"
"search_middleware_ssl": "{{ .Values.configuration.searchMiddleware.ssl }}"
"search_middleware_version": "{{ .Values.configuration.searchMiddleware.version }}"
{{- end -}}
